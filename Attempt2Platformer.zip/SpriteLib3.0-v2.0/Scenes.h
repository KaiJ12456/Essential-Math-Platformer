#ifndef __SCENES_H__
#define __SCENES_H__

#include "Scene.h"
#include "FirstCreation.h"
#include "PhysicsPlayground.h"

#endif // !__SCENES_H__
